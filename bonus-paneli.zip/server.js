const express = require("express");
const fs = require("fs");
const bodyParser = require("body-parser");
const app = express();

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static("public")); // HTML dosyaları için

const FILE = "talepler.json";

app.post("/bonus-talep", (req, res) => {
    const { username, bonus } = req.body;
    if (!username || !bonus) {
        return res.status(400).json({ message: "Eksik bilgi!" });
    }

    const yeniTalep = { username, bonus };
    let talepler = [];

    if (fs.existsSync(FILE)) {
        talepler = JSON.parse(fs.readFileSync(FILE));
    }

    talepler.push(yeniTalep);
    fs.writeFileSync(FILE, JSON.stringify(talepler, null, 2));

    res.json({ message: "Talep alındı!" });
});

app.get("/admin/talepler", (req, res) => {
    if (fs.existsSync(FILE)) {
        const talepler = JSON.parse(fs.readFileSync(FILE));
        res.json(talepler);
    } else {
        res.json([]);
    }
});

app.listen(3000, () => {
    console.log("http://localhost:3000 çalışıyor!");
});